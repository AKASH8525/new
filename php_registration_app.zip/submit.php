<?php
// Include the db.config.php file to get database credentials
require_once 'dbconfig.php';

// Create a connection to the database using credentials from db.config.php
$conn = new mysqli($host, $user, $pass, $db);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);  // Connection error handling
}

// Check if the form data is received from POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data from POST request
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);  // Hash the password before storing

    // Prepare an SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $password);  // "sss" means 3 string parameters

    // Execute the statement
    if ($stmt->execute()) {
        echo "Registration successful!";  // Success message
    } else {
        echo "Error: " . $stmt->error;  // Error message
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
